# ============================================================
#  EOLO — Dashboard Web (Cloud Run)
#  Lee datos de Firestore en tiempo real
#  URL: https://eolo-dashboard-XXXX-ue.a.run.app
# ============================================================
import os
import pytz
from collections import defaultdict
from datetime import date, datetime, timedelta
from flask import Flask, render_template, jsonify, request
from google.cloud import firestore

EASTERN = pytz.timezone("America/New_York")

app = Flask(__name__)

GCP_PROJECT       = "eolo-schwab-agent"
TRADES_COLLECTION = "eolo-trades"
CONFIG_COLLECTION = "eolo-config"
CONFIG_DOC        = "strategies"
TICKERS_DOC       = "tickers"
SETTINGS_DOC      = "settings"

BUDGET_MIN =   10      # USD mínimo por trade
BUDGET_MAX = 5000      # USD máximo por trade
BUDGET_DEFAULT = 100

# Tickers por defecto
DEFAULT_TICKERS = {
    # Clásicas (EMA + Gap)
    "SPY":  True,
    "QQQ":  True,
    "AAPL": True,
    "TSLA": True,
    "NVDA": True,
    # Apalancadas (VWAP + Bollinger + ORB)
    "SOXL": True,
    "TSLL": True,
    "NVDL": True,
    "TQQQ": True,
}

TICKER_GROUPS = {
    "clasicas":    ["SPY", "QQQ", "AAPL", "TSLA", "NVDA"],
    "apalancadas": ["SOXL", "TSLL", "NVDL", "TQQQ"],
}

# Tickers que puede operar cada estrategia (para el panel de semáforo)
STRATEGY_TICKERS = {
    "ema_crossover": ["SPY", "QQQ", "AAPL", "TSLA", "NVDA"],
    "gap_fade":      ["SPY", "QQQ", "AAPL", "TSLA", "NVDA"],
    "vwap_rsi":      ["SOXL", "TSLL", "NVDL", "TQQQ"],
    "bollinger":     ["SOXL", "TSLL", "NVDL", "TQQQ"],
    "orb":           ["SOXL", "TSLL", "NVDL", "TQQQ"],
}

# Mapeo: nombre en trades → clave de estrategia
TRADE_STRAT_MAP = {
    "EMA":       "ema_crossover",
    "GAP":       "gap_fade",
    "VWAP+RSI":  "vwap_rsi",
    "VWAP_RSI":  "vwap_rsi",
    "BOLLINGER": "bollinger",
    "ORB":       "orb",
}


def get_db():
    return firestore.Client(project=GCP_PROJECT)


def get_today_trades() -> list:
    today = date.today().strftime("%Y-%m-%d")
    db    = get_db()
    doc   = db.collection(TRADES_COLLECTION).document(today).get()
    if not doc.exists:
        return []
    data   = doc.to_dict() or {}
    trades = list(data.values())
    trades.sort(key=lambda x: x.get("timestamp", ""))
    return trades


def get_strategy_config() -> dict:
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(CONFIG_DOC).get()
    if doc.exists:
        return doc.to_dict() or {}
    return {"ema_crossover": True, "sma200_filter": True,
            "gap_fade": False, "vwap_rsi": False, "bollinger": False, "orb": False}


def get_settings() -> dict:
    """Lee settings globales: budget, bot_active."""
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(SETTINGS_DOC).get()
    defaults = {"budget": BUDGET_DEFAULT, "bot_active": True}
    if doc.exists:
        data = doc.to_dict() or {}
        defaults.update(data)
    return defaults


def get_live_positions() -> dict:
    """
    Lee las posiciones reales del bot desde eolo-config/positions.
    Más confiable que inferirlas de los trades del día (sobrevive reinicios).
    Retorna dict con:
      - open_tickers: {ticker: entry_price}  (solo los LONG)
      - by_strategy:  {strat_key: [ticker, ...]}
      - updated_at:   timestamp
    """
    try:
        db  = get_db()
        doc = db.collection(CONFIG_COLLECTION).document("positions").get()
        if doc.exists:
            data         = doc.to_dict() or {}
            positions    = data.get("positions",    {})
            entry_prices = data.get("entry_prices", {})
            updated_at   = data.get("updated_at",   "")
            open_tickers = {
                t: entry_prices.get(t)
                for t, v in positions.items()
                if v == "LONG"
            }
            return {"open_tickers": open_tickers, "updated_at": updated_at}
    except Exception:
        pass
    return {"open_tickers": {}, "updated_at": ""}


def build_strat_positions(open_tickers: dict, today_trades: list) -> dict:
    """
    Para cada ticker abierto, determina qué estrategia lo abrió
    buscando el último BUY de hoy. Agrupa por clave de estrategia.
    """
    # Último BUY por ticker
    last_buy_strat = {}
    for t in today_trades:
        if t.get("action") == "BUY":
            ticker = t.get("ticker", "")
            strat  = t.get("strategy", "")
            if ticker:
                last_buy_strat[ticker] = TRADE_STRAT_MAP.get(strat, "")

    by_strategy = {k: [] for k in STRATEGY_TICKERS}
    for ticker in open_tickers:
        strat_key = last_buy_strat.get(ticker, "")
        if strat_key and strat_key in by_strategy:
            by_strategy[strat_key].append(ticker)
        else:
            # Fallback: asignar por grupo de tickers
            for key, tlist in STRATEGY_TICKERS.items():
                if ticker in tlist:
                    by_strategy[key].append(ticker)
                    break
    return by_strategy


def get_ticker_config() -> dict:
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(TICKERS_DOC).get()
    if doc.exists:
        cfg = DEFAULT_TICKERS.copy()
        cfg.update(doc.to_dict() or {})
        return cfg
    return DEFAULT_TICKERS.copy()


def calc_pnl(trades: list) -> dict:
    by_ticker = defaultdict(list)
    for t in trades:
        by_ticker[t["ticker"]].append(t)

    total_pnl  = 0.0
    wins = losses = rounds = 0
    positions  = {}
    ticker_pnl = {}

    for ticker, ticker_trades in by_ticker.items():
        pnl = 0.0
        buy_price = None
        for trade in ticker_trades:
            price = float(trade["price"])
            shares = int(trade.get("shares", 1))
            if trade["action"] == "BUY":
                buy_price = price
                positions[ticker] = {"price": price, "time": trade["timestamp"],
                                     "shares": shares}
            elif trade["action"] == "SELL" and buy_price is not None:
                gain = (price - buy_price) * shares
                pnl += gain
                rounds += 1
                wins   += 1 if gain >= 0 else 0
                losses += 1 if gain <  0 else 0
                buy_price = None
                positions.pop(ticker, None)
        total_pnl          += pnl
        ticker_pnl[ticker]  = round(pnl, 4)

    return {
        "total_pnl":      round(total_pnl, 4),
        "wins":           wins,
        "losses":         losses,
        "rounds":         rounds,
        "win_rate":       round(wins / rounds * 100, 1) if rounds > 0 else 0,
        "open_positions": positions,
        "ticker_pnl":     ticker_pnl,
    }


# ── Routes ────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/data")
def api_data():
    trades    = get_today_trades()
    stats     = calc_pnl(trades)
    config    = get_strategy_config()
    tickers   = get_ticker_config()
    settings  = get_settings()
    live_pos  = get_live_positions()
    now_et    = datetime.now(EASTERN).strftime("%Y-%m-%d %H:%M:%S ET")

    # Posiciones por estrategia para el panel semáforo
    strat_pos = build_strat_positions(live_pos["open_tickers"], trades)

    return jsonify({
        "trades":           trades[-50:],
        "stats":            stats,
        "strategies":       config,
        "tickers":          tickers,
        "ticker_groups":    TICKER_GROUPS,
        "settings":         settings,
        "updated_at":       now_et,
        "trade_count":      len(trades),
        "live_positions":   {
            "open":       live_pos["open_tickers"],
            "by_strategy": strat_pos,
            "updated_at": live_pos["updated_at"],
        },
    })


@app.route("/api/toggle-strategy", methods=["POST"])
def toggle_strategy():
    data     = request.get_json()
    strategy = data.get("strategy")
    enabled  = data.get("enabled")
    if not strategy:
        return jsonify({"error": "strategy required"}), 400
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(CONFIG_DOC)
    doc.set({strategy: enabled}, merge=True)
    return jsonify({"ok": True, "strategy": strategy, "enabled": enabled})


@app.route("/api/toggle-ticker", methods=["POST"])
def toggle_ticker():
    """Activa o desactiva un ticker individual en Firestore."""
    data    = request.get_json()
    ticker  = data.get("ticker")
    enabled = data.get("enabled")
    if not ticker:
        return jsonify({"error": "ticker required"}), 400
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(TICKERS_DOC)
    doc.set({ticker: enabled}, merge=True)
    return jsonify({"ok": True, "ticker": ticker, "enabled": enabled})


@app.route("/api/toggle-ticker-group", methods=["POST"])
def toggle_ticker_group():
    """Activa o desactiva todos los tickers de un grupo."""
    data    = request.get_json()
    group   = data.get("group")
    enabled = data.get("enabled")
    tickers = TICKER_GROUPS.get(group, [])
    if not tickers:
        return jsonify({"error": "group not found"}), 400
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(TICKERS_DOC)
    doc.set({t: enabled for t in tickers}, merge=True)
    return jsonify({"ok": True, "group": group, "tickers": tickers, "enabled": enabled})


@app.route("/api/set-budget", methods=["POST"])
def set_budget():
    """Cambia el budget por trade (USD). Respeta min/max."""
    data   = request.get_json()
    amount = data.get("budget")
    try:
        amount = float(amount)
    except (TypeError, ValueError):
        return jsonify({"error": "invalid amount"}), 400
    amount = max(BUDGET_MIN, min(BUDGET_MAX, amount))
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(SETTINGS_DOC)
    doc.set({"budget": amount}, merge=True)
    return jsonify({"ok": True, "budget": amount,
                    "budget_min": BUDGET_MIN, "budget_max": BUDGET_MAX})


@app.route("/api/toggle-active", methods=["POST"])
def toggle_active():
    """Pausa o reanuda el bot globalmente (bot_active flag en Firestore)."""
    data    = request.get_json()
    enabled = bool(data.get("enabled", True))
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(SETTINGS_DOC)
    doc.set({"bot_active": enabled}, merge=True)
    return jsonify({"ok": True, "bot_active": enabled})


@app.route("/api/close-all-positions", methods=["POST"])
def close_all_positions():
    """
    Escribe un flag en Firestore para que el bot cierre todas las posiciones
    abiertas en el próximo ciclo (5 min máx).
    """
    db  = get_db()
    doc = db.collection(CONFIG_COLLECTION).document(SETTINGS_DOC)
    doc.set({"close_all": True, "close_all_ts": datetime.now(EASTERN).isoformat()}, merge=True)
    return jsonify({"ok": True, "message": "Close-all flag set — bot will close all positions on next cycle"})


@app.route("/api/performance")
def api_performance():
    """
    Retorna métricas de performance del día actual + historial de los últimos 30 días.
    - Por estrategia: trades, wins, losses, avg_win, avg_loss, pnl
    - Por ticker: pnl, trades
    - Equity curve del día (P&L acumulado por hora)
    - Historial diario: últimos 30 días de P&L total
    - Top trades (best / worst del día)
    """
    db = get_db()

    # ── Día actual ───────────────────────────────────────────
    today        = date.today().strftime("%Y-%m-%d")
    today_trades = get_today_trades()

    # Métricas por estrategia
    strat_stats = defaultdict(lambda: {
        "trades": 0, "wins": 0, "losses": 0,
        "win_amounts": [], "loss_amounts": [], "pnl": 0.0, "tickers": set()
    })

    # Métricas por ticker
    ticker_stats = defaultdict(lambda: {"pnl": 0.0, "trades": 0, "strategy": ""})

    # Equity curve: P&L acumulado por hora (9:30–16:00)
    equity_by_hour = defaultdict(float)

    # Para calcular trades completos (BUY→SELL) agrupados por ticker+estrategia
    open_buys = {}  # key: (ticker, strategy)

    # Top trades
    all_trades_pnl = []

    for t in today_trades:
        ticker   = t.get("ticker", "?")
        action   = t.get("action", "")
        strategy = t.get("strategy", "EMA")
        price    = float(t.get("price", 0))
        shares   = int(t.get("shares", 1))
        ts       = t.get("timestamp", "")
        hour_key = ts[11:13] + ":00" if len(ts) >= 13 else "??"

        key = (ticker, strategy)
        if action == "BUY":
            open_buys[key] = {"price": price, "shares": shares, "hour": hour_key}
        elif action == "SELL" and key in open_buys:
            buy  = open_buys.pop(key)
            gain = (price - buy["price"]) * buy["shares"]

            s = strat_stats[strategy]
            s["trades"] += 1
            s["pnl"]    += gain
            s["tickers"].add(ticker)
            if gain >= 0:
                s["wins"] += 1
                s["win_amounts"].append(gain)
            else:
                s["losses"] += 1
                s["loss_amounts"].append(gain)

            ticker_stats[ticker]["pnl"]    += gain
            ticker_stats[ticker]["trades"] += 1
            ticker_stats[ticker]["strategy"] = strategy
            equity_by_hour[hour_key]       += gain
            all_trades_pnl.append({"ticker": ticker, "strategy": strategy,
                                    "pnl": round(gain, 2), "hour": hour_key})

    # Formatear estrategias
    strat_result = {}
    for name, s in strat_stats.items():
        strat_result[name] = {
            "trades":   s["trades"],
            "wins":     s["wins"],
            "losses":   s["losses"],
            "win_rate": round(s["wins"] / s["trades"] * 100, 1) if s["trades"] > 0 else 0,
            "avg_win":  round(sum(s["win_amounts"])  / len(s["win_amounts"]),  2) if s["win_amounts"]  else 0,
            "avg_loss": round(sum(s["loss_amounts"]) / len(s["loss_amounts"]), 2) if s["loss_amounts"] else 0,
            "pnl":      round(s["pnl"], 2),
            "tickers":  sorted(s["tickers"]),
        }

    # Formatear ticker P&L para heatmap
    ticker_result = {t: {"pnl": round(v["pnl"], 2), "trades": v["trades"],
                         "strategy": v["strategy"]}
                     for t, v in ticker_stats.items()}

    # Equity curve ordenada
    hours_sorted = sorted(equity_by_hour.keys())
    cumulative, running = [], 0.0
    for h in hours_sorted:
        running += equity_by_hour[h]
        cumulative.append({"hour": h, "pnl": round(running, 2)})

    # Top / worst trades
    all_trades_pnl.sort(key=lambda x: x["pnl"], reverse=True)
    top_trades   = all_trades_pnl[:5]
    worst_trades = sorted(all_trades_pnl, key=lambda x: x["pnl"])[:3]

    # ── Historial últimos 30 días ─────────────────────────────
    history = []
    for i in range(29, -1, -1):
        day_str = (date.today() - timedelta(days=i)).strftime("%Y-%m-%d")
        try:
            doc = db.collection(TRADES_COLLECTION).document(day_str).get()
            if doc.exists:
                day_trades = list((doc.to_dict() or {}).values())
                day_pnl    = 0.0
                day_buys   = {}
                for t in sorted(day_trades, key=lambda x: x.get("timestamp", "")):
                    ticker   = t.get("ticker", "?")
                    strategy = t.get("strategy", "EMA")
                    action   = t.get("action", "")
                    price    = float(t.get("price", 0))
                    shares   = int(t.get("shares", 1))
                    k = (ticker, strategy)
                    if action == "BUY":
                        day_buys[k] = {"price": price, "shares": shares}
                    elif action == "SELL" and k in day_buys:
                        b = day_buys.pop(k)
                        day_pnl += (price - b["price"]) * b["shares"]
                history.append({"date": day_str, "pnl": round(day_pnl, 2)})
            else:
                history.append({"date": day_str, "pnl": None})  # sin datos
        except Exception:
            history.append({"date": day_str, "pnl": None})

    return jsonify({
        "date":          today,
        "strategies":    strat_result,
        "ticker_pnl":    ticker_result,
        "equity_curve":  cumulative,
        "top_trades":    top_trades,
        "worst_trades":  worst_trades,
        "history":       history,
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=False)
